import streamlit as st
import yfinance as yf
import pandas as pd
from src.portfolio_optimizer import mean_variance_optimizer

st.title("🧠 RoboAdvisorML – Smart Investment Recommender")

st.sidebar.header("Select Assets")
tickers = st.sidebar.multiselect("Tickers", ["AAPL", "MSFT", "GOOGL", "AMZN", "SPY"])

if tickers:
    st.write("## Asset Prices")
    data = yf.download(tickers, period="1y")['Adj Close']
    st.line_chart(data)

    st.write("## Optimized Portfolio")
    returns = data.pct_change().dropna()
    weights = mean_variance_optimizer(returns)
    st.write(pd.Series(weights, index=returns.columns).round(3))

import numpy as np

def mean_variance_optimizer(returns):
    cov_matrix = returns.cov()
    mean_returns = returns.mean()
    inv_cov = np.linalg.inv(cov_matrix)
    weights = inv_cov.dot(mean_returns)
    weights /= weights.sum()
    return weights
